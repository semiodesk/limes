﻿namespace Profiles.DIRECT.Utilities
{
    public class DirectConfig
    {
        public DirectConfig() { }        
        public string PopulationType { get; set; }
        public int Timeout { get; set; }
    }
}
